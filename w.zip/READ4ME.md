# CloudFlareBypass
Layer 7 Script that can Bypass the CloudFlare's UAM (Under Attack Mode)

Proof of Power: Testing purposes only - https://vid.me/cfstv

I will be not responsable of any damage that you will create with this script.
This is learning/testing purposes only.

Dependencies:
- PHP 5.4 or higher
- PHP Curl Extension

Telegram: https://t.me/Vaiiry
